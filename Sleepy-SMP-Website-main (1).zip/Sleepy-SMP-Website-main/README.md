# Sleepy SMP Website
Website for Minecraft Sleepy SMP Server

## Basic Information
All website files are in folder `www`.
Images are in `www/resource` folder.

## How to Setup
To setup website, follow these instructions:

* Download files of Sleepy SMP Website
* Unzip them in your website folder (`htdocs`, `www`,...)
* Test website

## Troubleshooting
Didn't work? Here are some solutions to try:

* Move all files outside from `www` folder.
* Restart website.
* Check if webserver can support PHP. If it doesn't
  support PHP, try to find webserver that supports it.

---

This website is tested using 
[XAMPP Apache Server](https://www.apachefriends.org/index.html).